from django.shortcuts import render
import urllib.parse
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
import asyncio
import aiohttp
from bs4 import BeautifulSoup

async def fetch_article(session, url):
    async with session.get(url, timeout=10) as response:
        return await response.text()

async def fetch_articles_async(query, num_articles=5):
    articles = []
    start = 0
    analyzer = SentimentIntensityAnalyzer()
    encoded_query = urllib.parse.quote_plus(query)

    async with aiohttp.ClientSession() as session:
        while len(articles) < num_articles and start < 100:
            url = f'https://www.google.com/search?q={encoded_query}&tbm=nws&start={start}'
            print(f"Fetching URL: {url}")
            response_text = await fetch_article(session, url)
            soup = BeautifulSoup(response_text, 'html.parser')

            for item in soup.find_all('a'):
                link = item.get('href')
                if link and '/url?q=' in link:
                    title_element = item.find('div', class_='BNeawe vvjwJb AP7Wnd')
                    if title_element:
                        title = title_element.get_text()
                        link = link.split('/url?q=')[1].split('&')[0]
                        decoded_link = urllib.parse.unquote(link)

                        # Analyze the sentiment of the article title
                        sentiment = analyzer.polarity_scores(title)
                        if sentiment['neg'] > 0.5:
                            articles.append({
                                'title': title,
                                'link': decoded_link,
                                'negative_score': sentiment['neg']
                            })
                            if len(articles) >= num_articles:
                                break

            start += 10  # Go to the next page of results
            print(f"Number of articles fetched: {len(articles)}")

    return articles

def search(request):
    query = request.GET.get('q')
    articles = []
    if query:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        print(f"Starting to fetch articles for query: {query}")
        articles = loop.run_until_complete(fetch_articles_async(query))
        print(f"Finished fetching articles. Total articles: {len(articles)}")

    return render(request, 'index.html', {'articles': articles})
